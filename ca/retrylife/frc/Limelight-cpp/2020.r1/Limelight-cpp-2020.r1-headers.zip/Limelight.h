#pragma once
#include <iostream>

namespace retrylife::frc {
class Limelight {
   public:
    Limelight();
};
}  // namespace retrylife::frc