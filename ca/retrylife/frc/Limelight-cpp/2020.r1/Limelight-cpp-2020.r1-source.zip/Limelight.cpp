#include "Limelight.h"
using namespace retrylife::frc;

Limelight::Limelight() {
    std::cout << "Warning: Limelight client CPP support is not complete. "
                 "Please use your own NetworkTables client"
              << std::endl;
}